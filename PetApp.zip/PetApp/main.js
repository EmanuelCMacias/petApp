window.addEventListener('load', event => {
  document.cookie = "username=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";

  fetchAnimals();
});


// fetch animals from API
function fetchAnimals() {

  let key = "hoqrxqQlhzsj6RDkCUARWcAHCX3IQcFIeSliFnkSuAMLmeOsTo";
  let secret = "fAAqIYI8D76qNuLeqELhKXC1bnC1TFd8rxebBNgh";
  let token;

  // get authorization token
  fetch("https://api.petfinder.com/v2/oauth2/token", {
    method: "POST",
    body:
      "grant_type=client_credentials&client_id=" +
      key +
      "&client_secret=" +
      secret,
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
  })
    .then((res) => res.json())
    .then((data) => {
      token = data.access_token;
    })
    .then(() => {
      // use token to fetch animals
      fetch(
        `https://api.petfinder.com/v2/animals?&location=27405`,
        {
          method: "GET",
          mode: "cors",
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + token,
          },
        }
      )
        .then((res) => res.json())
        .then((data) => showAnimals(data.animals));

    })
    .catch((err) => console.error(err));
}

// show listings of pets
function showAnimals(pets) {
  const results = document.querySelector("#results");
  

  // clear results first
  results.innerHTML = "";

  let counter = 0;
  // loop through pets
  
  pets.forEach((pet) => {
    /* console.log(pet); */
    // create elements
    if (counter == 20) {
      return;
    }

    counter++;
    let x;
    if (pet.photos[0] == null && pet.photos[1] == null) {
      x = "assets/dog1Edited.png";
    } else {
      x = pet.photos[0] ? pet.photos[0].medium:"";
    }

    const style = document.createElement('style');


// add CSS styles
    const div = document.createElement("div");
   
    div.innerHTML = `
    <div class="container">
    <div class="card" style="width:600px ">
    <img class="card-img-top" src="${x}" alt="Card image" style="width:100%">
    <div class="card-body">
      <h4 class="card-title">${pet.name} (${pet.age})</h4>
      <p class="text-secondary">${pet.breeds.primary}</p>
      <p>${pet.contact.address.city}, ${pet.contact.address.state} ${pet.contact.address.postcode
      }</p>
        <ul class="list-group">
          <li class="list-group-item">${pet.contact.phone
      ? `<li class="list-group-item">Phone: ${pet.contact.phone}</li>`
      : ``
      }</li>
          ${pet.contact.email
      ? `<li class="list-group-item">Email: ${pet.contact.email}</li>`
      : ``
      }
          <li class="list-group-item">Shelter ID: ${pet.organization_id}</li>
        </ul>
      
      <a href="Petpage.php" class="btn btn-primary stretched-link">View Bookmarks</a>
      <button id="demo"type="button" onclick="setPetId(${pet.id})">Bookmark</button>
    </div>
  </div>
</div>`;
style.innerHTML = `
.card {
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition: 0.3s;
  width: 100%;
}

.card:hover {
  box-shadow: 0 8px 16px 0 #6504b5;
}

.container {
  padding: 1rem 0 0 0;
  height: 75%;
  display:grid;
  justify-content: center;
}
@media screen and (max-width: 992px) {
  .column {
    width: 50%;
  }
}
button {
  margin: 1rem 0 0 0;
  border-radius: 5px;  
  height: 2.5rem;
  background-color: #845ec2;

}
`;

document.head.appendChild(style);
    results.appendChild(div);

  });
}


/* <div class="row">
<div class="col-sm-6">
  <h4>${pet.name} (${pet.age})</h4>
  <p class="text-secondary">${pet.breeds.primary}</p>
  <p>${pet.contact.address.city}, ${pet.contact.address.state} ${pet.contact.address.postcode
}</p>
  <ul class="list-group">
    <li class="list-group-item">${pet.contact.phone
? `<li class="list-group-item">Phone: ${pet.contact.phone}</li>`
: ``
}</li>
    ${pet.contact.email
? `<li class="list-group-item">Email: ${pet.contact.email}</li>`
: ``
}
    <li class="list-group-item">Shelter ID: ${pet.organization_id}</li>
  </ul>

</div>
<div class="col-sm-6">
<img class="img-fluid rounded-circle mt-2" src="${x}"/>
</div>
</div> */