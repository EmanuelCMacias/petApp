<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=`, initial-scale=1.0">
  <link rel="stylesheet" href="homepage.css">
  <title>PetPage</title>
</head>

<body>
  <form method="POST">
    <div class="header">
      <a href="Homepage.php" class="logo">PetAdoption Assistant</a>
      <div class="header-right">
        <a class="active" href="HomePage.php">Home</a>
        <a href="logout.php">Logout</a>
      </div>
    </div>
    <div id="results"></div>
    <!----------------------------------------------------------------------->
    <!----------------------------------------------------------------------->

    <script src="second.js"></script>
</body>
</html>

<script>
  function removeBook(petData) {

    document.cookie = "username=" + petData;

    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(' ');

    for (let index = 0; index < ca.length; index++) {
    str = ca[index]
    str = str.replace(';', '');
    str = str.slice(2);
    if (str.length == 8 ) {
      if (str == petData) {
        document.cookie = index +"=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
      }            
    }
    
  }
    for (var i = 0; i < localStorage.length; i++) {
       if (petData == localStorage.getItem(localStorage.key(i))) {
        localStorage.removeItem(localStorage.key(i));
       }
    }

    window.location.reload();

  }

</script>
<?php 
error_reporting(E_ALL);
ini_set('display_errors', 0);

if (isset($_POST['logout'])) {
	header("location:logout.php");
}

session_start();


$con = mysqli_connect('localhost', 'root', '', 'PetLoginData');

$uname = $_SESSION['uname'];

$sql = "SELECT * FROM bookmarks WHERE Username = '$uname'";
$result = $con->query($sql);

$counter = 1;

  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        //echo "<br> id: ". $row["id"] . " ". $counter ."<br>";
        setcookie($counter, $row['id'], time() + (86400 * 30), "/");
        $counter++;
    }
  } else {
    echo "0 results";
  }



$con->close();

$conn = mysqli_connect('localhost', 'root', '', 'PetLoginData');
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$idFinal = $_COOKIE["username"];
// sql to delete a record
$sql= "DELETE FROM bookmarks WHERE id= $idFinal";

if ($conn->query($sql) === TRUE) {
  echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . $conn->error;
}

$conn->close();
if ($_SESSION['uname']) {
 }else{
 	header("location:PetLogin.php");
 }
?>
<script>
  let index = "username";  
  document.cookie = index +"=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
</script>
