window.addEventListener('load', event => {
    document.cookie = "username=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
  
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(' ');
  
    for (let index = 0; index < ca.length; index++) {
      str = ca[index]
      str = str.replace(';', '');
      str = str.slice(2);
      if (str.length == 8 ) {
        fetchAnimals(str)
        document.cookie = index +"=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
        
        //console.log(str);            
      }
      
    }
  
    // for(let i = 0; i < ca.length; i++) {
    //   let c = ca[i];
    //   console.log(ca + "" );
  
    //   while (c.charAt(0) == ' ') {
    //     c = c.substring(1);
    //   }
    //   if (c.indexOf(name) == 0) {
    //     return c.substring(name.length, c.length);
    //   }
    // }
  });
  
  
  // for (var i = 0; i < localStorage.length; i++) {
  //   fetchAnimals(localStorage.getItem(localStorage.key(i)));
  // }
  
  
  
  function fetchAnimals(pet_id) {
  
    let key = "hoqrxqQlhzsj6RDkCUARWcAHCX3IQcFIeSliFnkSuAMLmeOsTo";
    let secret = "fAAqIYI8D76qNuLeqELhKXC1bnC1TFd8rxebBNgh";
    let token;
  
    // get authorization token
    fetch("https://api.petfinder.com/v2/oauth2/token", {
      method: "POST",
      body:
        "grant_type=client_credentials&client_id=" +
        key +
        "&client_secret=" +
        secret,
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
    })
      .then((res) => res.json())
      .then((data) => {
        token = data.access_token;
      })
      .then(() => {
        // use token to fetch animals
        fetch(
          `https://api.petfinder.com/v2/animals/${pet_id}`,
          {
            method: "GET",
            mode: "cors",
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + token,
            },
          }
        )
          .then((res) => res.json())
          .then((data) => showAnimals(data));
      })
      .catch((err) => console.error(err));
  }
  
  // show listings of pets
  function showAnimals(pets) {
    const results = document.querySelector("#results");
    const chosen = document.querySelector("#chosen");
  
    // clear results first
    //results.innerHTML = "";
  
    let counter = 0;
    //   loop through pets
    const style = document.createElement('style');
    
  //console.log(pets.animal.name);
    let petData = pets.animal;
  
    let x;
    if(petData.photos[0] == null) {
        x = "assets/dog1Edited.png";
    } else {
      x = petData.photos[0] ? petData.photos[0].medium : "";
    }
  
  
    // add CSS styles
  
    const div = document.createElement("div");
    div.innerHTML = `
       <div class="container" style="height:30%">
       <div class="card" style="width:600px ">
           <img class="card-img-top" src="${x}" alt="Card image" style="width:100%">
       <div class="card-body">
         <h4 class="card-title">${petData.name} (${petData.age})</h4>
         <p class="text-secondary">${petData.breeds.primary}</p>
         <p>${petData.contact.address.city}, ${petData.contact.address.state} ${petData.contact.address.postcode
      }</p>
           <ul class="list-group">
             <li class="list-group-item">${petData.contact.phone
        ? `<li class="list-group-item">Phone: ${petData.contact.phone}</li>`
        : ``
      }</li>
             ${petData.contact.email
        ? `<li class="list-group-item">Email: ${petData.contact.email}</li>`
        : ``
      }
             <li class="list-group-item">Shelter ID: ${petData.organization_id}</li>
           </ul>
         <button id="demo"type="button">Like</button>
       </div>
     </div>
   </div>`;
   style.innerHTML = `
  .card {
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
    transition: 0.3s;
    width: 100%;
  }
  
  .card:hover {
    box-shadow: 0 8px 16px 0 #6504b5;
  }
  
  .container {
    padding: 1rem 0 0 0;
    height: 20%;
    display:grid;
    justify-content: center;
  }
  @media screen and (max-width: 992px) {
    .column {
      width: 50%;
    }
  }
  button {
    margin: 1rem 0 0 0;
    border-radius: 5px;  
    height: 2.5rem;
    background-color: #6504b5;
  
  }
  `;
    document.head.appendChild(style);
    results.appendChild(div);
  
  }