<!DOCTYPE html>

<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB"
    crossorigin="anonymous">
	<title>Login Page</title>

<style>
.card{
	margin-bottom: 10x;
}
</style>

</head>
<body>
	<link rel="stylesheet" type="text/css" href="homepage.css">

<form method="POST">	
<div class="header">
  	<a href="Homepage.php" class="logo">PetAdoption Assistant</a>
  	<div class="header-right">
    	<a class="active" href="HomePage.php">Home</a>
    	<a class="active" href="highlighted.php">Highlighted</a>
    	<a href="logout.php">Logout</a>
  </div>
</div>

<div class="container">
    <form id="pet-form">
      <div class="form-group">
        <label for="animal">Animal</label>
        <select id="animal" class="form-control form-control-lg mb-3">
          <option value="cat">Cat</option>
          <option value="dog">Dog</option>
          <option value="bird">Bird</option>
          <option value="barnyard">Barnyard</option>
        </select>
        <input type="text" id="zip" class="form-control form-control-lg" placeholder="Enter your zipcode">
        <input type="submit" value="Find" class="btn btn-dark btn-lg btn-block mt-3">
      </div>
    </form>
    <div id="results"></div>
    <p id="tests"></p>    


  </div>

  <script src="main.js"></script>

<div class="footer">
  <p>@2022 PetAdoption Assistant</p>
</div>


</body>
</html>

<script>
function myFunction() {
  var input, filter, ul, li, a, i;
  input = document.getElementById("mySearch");
  filter = input.value.toUpperCase();
  ul = document.getElementById("myMenu");
  li = ul.getElementsByTagName("li");
  for (i = 0; i < li.length; i++) {
    a = li[i].getElementsByTagName("a")[0];
    if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
      li[i].style.display = "";
    } else {
      li[i].style.display = "none";
    }
  }
}

function setPetId(pet_id){
  
  document.cookie = "username=" + pet_id;
  document.getElementById("tests").innerHTML = pet_id;

  // if (localStorage.getItem("id1") == null) {
  //   localStorage.setItem('id1', pet_id);    
  // } else if(pet_id != localStorage.getItem("id1") && null == localStorage.getItem("id2")){
  //   localStorage.setItem('id2', pet_id);    
  // } else if(pet_id != localStorage.getItem("id2") && pet_id != localStorage.getItem("id1") && null == localStorage.getItem("id3")){
  //   localStorage.setItem('id3', pet_id);     
  // } else if(pet_id != localStorage.getItem("id3") && pet_id != localStorage.getItem("id1") && pet_id != localStorage.getItem("id2") && null == localStorage.getItem("id4")){
  //   localStorage.setItem('id4', pet_id);    
  // } else if(pet_id != localStorage.getItem("id4") && pet_id != localStorage.getItem("id1") && pet_id != localStorage.getItem("id3") && pet_id != localStorage.getItem("id2")&& null == localStorage.getItem("id5")){
  //   localStorage.setItem('id5', pet_id);    
  // } else if(localStorage.getItem("id1") != null && localStorage.getItem("id2") != null && localStorage.getItem("id3") != null && localStorage.getItem("id4") != null && localStorage.getItem("id5") != null) {
  //   window.alert('Bookmark full');
  // }
window.location.reload();
document.cookie = "username=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";


}
</script>


<?php
setcookie("username", "", time() - 3600);

error_reporting(E_ALL);
ini_set('display_errors', 0);

if (isset($_POST['logout'])) {
	header("location:logout.php");
}

session_start();
$con = mysqli_connect('localhost', 'root', '', 'PetLoginData');


$nameUser = $_SESSION['uname'];
if ($_COOKIE["username"] != null) {
  $id = $_COOKIE["username"];
  if($id != 0){
    $sql = "INSERT INTO bookmarks VALUES ('$nameUser','$id')";
    $res = mysqli_query($con, $sql);
    setcookie("username", "", time() - 3600);
    
  }
} 


if ($_SESSION['uname']) {
	//echo "Welcome " . $_SESSION['uname'];
 }else{
 	header("location:PetLogin.php");
 }
?> 